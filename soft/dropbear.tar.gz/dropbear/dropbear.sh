#!/bin/sh
export PATH=/tmp/dropbear/bin:/tmp/dropbear/sbin:/bin:/usr/bin:/sbin:/usr/sbin:/tmp/sbin:/tmp/bin:/tmp/openvpn/bin
export LD_LIBRARY_PATH=/tmp/dropbear/lib:/lib:/usr/lib:/jffs/lib:/jffs/usr/lib:/jffs/usr/local/lib:/mmc/lib:/mmc/usr/lib:/opt/lib:/opt/usr/lib:/tmp/openvpn/lib

if [ -z "`netstat -lnt|grep 0.0.0.0:22`" ]; then
	port=22
elif [ -z "`netstat -lnt|grep 0.0.0.0:2222`" ];then
	port=2222
else
	/usr/bin/logger -p DAEMON.INFO -t "Dropbear[$$]" "port 22/2222 has been used, dropbear not start"
	echo "port 22/2222 has been used, dropbear not start"
	exit 0
fi
mkdir -p ~/.ssh
rm -f ~/.ssh/authorized_keys
cp /tmp/dropbear/etc/authorized_keys ~/.ssh/
chmod 700 ~/.ssh
chmod 600 ~/.ssh/*
chmod +x /tmp/dropbear/sbin/dropbear
mkdir -p /tmp/var/run
/tmp/dropbear/sbin/dropbear -i -s -g -w -a -p $port -P /tmp/var/run/dropbear.pid &
